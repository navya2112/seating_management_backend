package com.example.seating_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeatingManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeatingManagementApplication.class, args);
	}

}
