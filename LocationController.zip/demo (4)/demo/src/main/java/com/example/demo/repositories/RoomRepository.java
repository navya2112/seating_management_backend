////package com.example.demo.repositories;
////
////
////
////import java.util.List;
////
////import org.springframework.data.jpa.repository.JpaRepository;
////import org.springframework.data.jpa.repository.Query;
////
////import com.example.demo.models.Room;
////import com.example.demo.models.RoomId;
////
/////**
//// * Repository for Room entity.
//// */
////public interface RoomRepository extends JpaRepository<Room, RoomId> {
////
////    // Find rooms by location
////    List<Room> findByIdLocation(String location);
////
////    // Get all distinct locations
////    @Query("SELECT DISTINCT r.id.location FROM Room r")
////    List<String> findAllLocations();
////    
////
//// // Search locations by partial name match using JPQL
////     @Query("SELECT r FROM Room r WHERE LOWER(r.id.location) LIKE LOWER(CONCAT('%', :name, '%'))")
////     List<Room> searchRoomsByLocationName(String name);
////
////}
////
//package com.example.demo.repositories;
//
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//
//import com.example.demo.models.Room;
//import com.example.demo.models.RoomId;
//
///**
// * Repository for Room entity.
// */
//public interface RoomRepository extends JpaRepository<Room, RoomId> {
//
//    // Find rooms by location
//    List<Room> findByIdLocation(String location);
//
//    // Get all distinct locations
//    @Query("SELECT DISTINCT r.id.location FROM Room r")
//    List<String> findAllLocations();
////
////    // Search rooms by partial location name
////    @Query("SELECT r FROM Room r WHERE LOWER(r.id.location) LIKE LOWER(CONCAT('%', :name, '%'))")
////    List<Room> searchRoomsByLocationName(String name);
//
//
// // Search rooms by partial location name using JPQL
//     @Query("SELECT r FROM Room r WHERE LOWER(r.id.location) LIKE LOWER(CONCAT('%', :name, '%'))")
//     List<Room> searchRoomsByLocationName(@Param("name") String name);
//
// 
//    // Filter rooms where occupancy percentage is greater than a value
//    @Query("SELECT r FROM Room r WHERE r.seatCount > 0 AND (r.canBeUtilizedSeats * 1.0 / r.seatCount) * 100 > :value")
//    List<Room> findRoomsByOccupancyGreaterThan(double value);
//
//    // Filter rooms where occupancy percentage is less than a value
//    @Query("SELECT r FROM Room r WHERE r.seatCount > 0 AND (r.canBeUtilizedSeats * 1.0 / r.seatCount) * 100 < :value")
//    List<Room> findRoomsByOccupancyLessThan(double value);
//}
//
package com.example.demo.repositories;

import com.example.demo.models.Room;
import com.example.demo.models.RoomId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Repository for Room entity using JPQL to fetch only filtered data.
 */
public interface RoomRepository extends JpaRepository<Room, RoomId> {

    // Find rooms by exact location
    List<Room> findByIdLocation(String location);

    // Get all distinct locations
    @Query("SELECT DISTINCT r.id.location FROM Room r")
    List<String> findAllLocations();



    // Filter rooms where occupancy percentage is greater than a value
    @Query("SELECT r FROM Room r WHERE r.seatCount > 0 AND (r.canBeUtilizedSeats * 1.0 / r.seatCount) * 100 > :value")
    List<Room> findRoomsByOccupancyGreaterThan(@Param("value") double value);
    
    @Query("SELECT r FROM Room r WHERE LOWER(r.id.location) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Room> searchRoomsByLocationName(@Param("name") String name);


    // Filter rooms where occupancy percentage is less than a value
    @Query("SELECT r FROM Room r WHERE r.seatCount > 0 AND (r.canBeUtilizedSeats * 1.0 / r.seatCount) * 100 < :value")
    List<Room> findRoomsByOccupancyLessThan(@Param("value") double value);
}

