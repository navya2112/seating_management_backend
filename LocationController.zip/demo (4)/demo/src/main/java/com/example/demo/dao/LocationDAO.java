//package com.example.demo.dao;
//
//
////	import com.example.demo.models.Location;
////	import com.example.demo.repositories.LocationRepository;
////	import org.springframework.beans.factory.annotation.Autowired;
////	import org.springframework.stereotype.Repository;
////
////	import java.util.List;
////	import java.util.Optional;
//
//
//import com.example.demo.models.Location;
//import com.example.demo.repositories.LocationRepository;
//
//import java.util.List;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//
//	@Repository
//	public class LocationDAO {
//
//	    @Autowired
//	    private LocationRepository locationRepository;
//
//	    public List<Location> findAllLocations() {
//	        return locationRepository.findAll();
//	    }
//
//	    public Optional<Location> findLocationById(Long id) {
//	        return locationRepository.findById(id);
//	    }
//
//	    public List<Location> findLocationsByName(String name) {
//	        return locationRepository.findByNameContainingIgnoreCase(name);
//	    }
//
//	    public Location saveLocation(Location location) {
//	        return locationRepository.save(location);
//	    }
//
//	    public void deleteLocation(Long id) {
//	        locationRepository.deleteById(id);
//	    }
//	}
//
//
//
package com.example.demo.dao;

import com.example.demo.models.Room;
import com.example.demo.repositories.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * DAO layer for accessing Room data.
 */
@Repository
public class LocationDAO {

    @Autowired
    private RoomRepository roomRepository;

    public List<Room> getRoomsByLocation(String location) {
        return roomRepository.findByIdLocation(location);
    }

    public List<Room> getAllRooms() {
        return roomRepository.findAll();
    }

    public List<String> getAllLocations() {
        return roomRepository.findAllLocations();
    }
}

